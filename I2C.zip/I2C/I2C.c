/**************************************************************************
 * FileName:        I2C.c
 * Dependencies:    I2C.h
 * Processor:       ESP32-WROOM-32
 * Board:           Generic
 * Program version: Eclipse IDE V. 4.27.0
 * Company:         ITCH
 * Description:     Descripción general del I2C.
 * Authors:         Mario Alejandro Briones Lara.
 * Updated:         06/2023
 ***************************************************************************/

#include <stdio.h>
#include "I2C.h"

// Definiciones de los registros de la interfaz I2C
#define I2C_CTRL_REG    0x3FF50000  // Registro de control de la I2C
#define I2C_DATA_REG    0x3FF50004  // Registro de datos de la I2C
#define I2C_ADDR_REG    0x3FF50008  // Registro de dirección de la I2C
#define I2C_STATUS_REG  0x3FF5000C  // Registro de estado de la I2C

/**************************************************************************
 * Function: I2C_Init
 * Preconditions: -
 * Overview: Inicializa la interfaz I2C.
 * Input: -
 * Output: -
 ***************************************************************************/

void I2C_Init(void) {
    // Inicialización de la interfaz I2C

    // Configurar los registros y parámetros necesarios para la I2C
    // Por ejemplo, configurar la velocidad de transferencia, el modo de operación, etc.

    // Configurar la velocidad de transferencia a 400 kHz
    uint32_t i2c_clk_div = 80;  // Frecuencia de reloj de la I2C en MHz
    uint32_t i2c_speed = 400;   // Velocidad de transferencia en kHz
    uint32_t divisor = i2c_clk_div * 1000 / (i2c_speed * 2);
    REG_WRITE(I2C_CTRL_REG, (divisor & 0xFFFF));

    // Otros ajustes de configuración de la I2C

    printf("I2C initialized\n");
}

/**************************************************************************
 * Function: I2C_WriteData
 * Preconditions: Se debe llamar a I2C_Init antes de utilizar esta función.
 * Overview: Escribe datos en un dispositivo I2C.
 * Input: address - Dirección del dispositivo I2C.
 *        data - Puntero al arreglo de datos a escribir.
 *        length - Longitud de los datos a escribir.
 * Output: -
 ***************************************************************************/

void I2C_WriteData(uint8_t address, uint8_t* data, uint8_t length) {
    // Escritura de datos a un dispositivo I2C

    // Esperar hasta que la interfaz I2C esté disponible
    while (REG_READ(I2C_STATUS_REG) & (1 << 7));

    // Establecer la dirección del dispositivo de destino en el registro de dirección
    REG_WRITE(I2C_ADDR_REG, address);

    // Escribir los datos en el registro de datos de la I2C
    for (int i = 0; i < length; i++) {
        REG_WRITE(I2C_DATA_REG, data[i]);
    }

    // Iniciar la transferencia de escritura
    REG_WRITE(I2C_CTRL_REG, (1 << 0));

    // Esperar hasta que la transferencia se complete
    while (REG_READ(I2C_STATUS_REG) & (1 << 0));

    printf("Data written to I2C\n");
}

/**************************************************************************
 * Function: I2C_ReadData
 * Preconditions: Se debe llamar a I2C_Init antes de utilizar esta función.
 * Overview: Lee datos desde un dispositivo I2C y los almacena en un buffer.
 * Input: address - Dirección del dispositivo I2C.
 *        buffer - Puntero al arreglo de datos para almacenar los datos leídos.
 *        length - Longitud de los datos a leer.
 * Output: -
 ***************************************************************************/

void I2C_ReadData(uint8_t address, uint8_t* buffer, uint8_t length) {
    // Lectura de datos desde un dispositivo I2C
    // Almacenamiento de los datos leídos en el buffer

    // Esperar hasta que la interfaz I2C esté disponible
    while (REG_READ(I2C_STATUS_REG) & (1 << 7));

    // Establecer la dirección del dispositivo de destino en el registro de dirección
    REG_WRITE(I2C_ADDR_REG, address);

    // Iniciar la transferencia de lectura
    REG_WRITE(I2C_CTRL_REG, (1 << 1));

    // Leer los datos desde el registro de datos de la I2C y almacenarlos en el buffer
    for (int i = 0; i < length; i++) {
        // Esperar hasta que se reciba un byte
        while (!(REG_READ(I2C_STATUS_REG) & (1 << 1)));

        // Leer el byte desde el registro de datos de la I2C y almacenarlo en el buffer
        buffer[i] = REG_READ(I2C_DATA_REG);
    }

    printf("Data read from I2C\n");
}
