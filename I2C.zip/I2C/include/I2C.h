/**************************************************************************
 * FileName:        I2C.h
 * Dependencies:    stdint
 * Processor:       ESP32-WROOM-32
 * Board:           Generic
 * Program version: Eclipse IDE V. 4.27.0
 * Company:         ITCH
 * Description:     Descripción general del I2C.
 * Authors:         Mario Alejandro Briones Lara.
 * Updated:         06/2023
 ***************************************************************************/

#ifndef I2C_H
#define I2C_H

#include <stdint.h>

// Declaración de funciones públicas

//Inicializa la interfaz I2C.
void I2C_Init(void);
// Escribe datos en un dispositivo I2C.
void I2C_WriteData(uint8_t address, uint8_t* data, uint8_t length);
//Lee datos desde un dispositivo I2C y los almacena en un buffer.
void I2C_ReadData(uint8_t address, uint8_t* buffer, uint8_t length);
//Lee un valor de un registro.
uint32_t REG_READ(uint32_t address);
//Escribe un valor en un registro.
void REG_WRITE(uint32_t address, uint32_t value);

// Implementación de las funciones
//Lee un valor de un registro.
uint32_t REG_READ(uint32_t address) {
    volatile uint32_t* reg_ptr = (uint32_t*)address;
    return *reg_ptr;
}
//Escribe un valor en un registro.
void REG_WRITE(uint32_t address, uint32_t value) {
    volatile uint32_t* reg_ptr = (uint32_t*)address;
    *reg_ptr = value;
}

#endif /* I2C_H */
