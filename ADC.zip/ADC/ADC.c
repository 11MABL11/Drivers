/***************************************************************************
 * FileName:        ADC.c
 * Dependencies:    ADC.h
 * Processor:       ESP32-WROOM-32
 * Board:           Generic
 * Program version: Eclipse IDE V. 4.27.0
 * Company:         ITCH
 * Description:     Descripción general del ADC.
 * Authors:         Mario Alejandro Briones Lara.
 * Updated:         06/2023
 ***************************************************************************/

#include <stdio.h>
#include "ADC.h"

#define REG_READ(addr) (*(volatile uint32_t *)(addr))
#define REG_WRITE(addr, value) ((*(volatile uint32_t *)(addr)) = (value))

#define ADC_CTRL_REG      0x3FF4F000  // Registro de control del ADC
#define ADC_ENABLE_BIT    0
#define ADC_START_BIT     2
#define ADC_WIDTH_BIT     3
#define ADC_WIDTH_12_BIT  0x3
#define ADC_WIDTH_MASK    0x3
#define ADC_CHANNEL_REG   0x3FF4F014  // Registro de selección de canal del ADC
#define ADC_CHANNEL_MASK  0x1F
#define ADC_CHANNEL_SHIFT 0
#define ADC_DATA_REG      0x3FF4F020  // Registro de datos del ADC

uint8_t selectedPin;

/***************************************************************************
 * Function: ADC_Init
 * Preconditions: -
 * Overview: Inicializa el ADC.
 * Input:
 *     - pin: Número de pin para configurar el ADC.
 * Output: -
 ***************************************************************************/

void ADC_Init(uint8_t pin) {
    // Verificar si el pin es válido
    if (pin != PIN0 && pin != PIN2 && pin != PIN4 && pin != PIN15) {
        printf("Error: Invalid pin selected for ADC\n");
        return;
    }

    // Guardar el pin seleccionado
    selectedPin = pin;

    // Inicialización del ADC

    // Habilitar el ADC
    REG_WRITE(ADC_CTRL_REG, REG_READ(ADC_CTRL_REG) | (1 << ADC_ENABLE_BIT));

    // Configurar la resolución del ADC a 12 bits (0-4095)
    REG_WRITE(ADC_CTRL_REG, (REG_READ(ADC_CTRL_REG) & ~(ADC_WIDTH_MASK << ADC_WIDTH_BIT)) |
                            (ADC_WIDTH_12_BIT << ADC_WIDTH_BIT));
}

/***************************************************************************
 * Function: ADC_ReadValue
 * Preconditions: Se debe llamar a ADC_Init antes de utilizar esta función.
 * Overview: Lee el valor analógico del pin especificado.
 * Input:
 *     - pin: Número de pin para leer el valor analógico.
 * Output:
 *     - uint16_t: Valor analógico leído del pin.
 ***************************************************************************/

uint16_t ADC_ReadValue(uint8_t pin) {
    // Verificar si el pin es válido
    if (pin != PIN0 && pin != PIN2 && pin != PIN4 && pin != PIN15) {
        printf("Error: Invalid pin selected for ADC read\n");
        return 0;
    }

    // Lectura del valor del ADC
    uint16_t valor_leido_adc = 0; // Variable para almacenar el valor leído

    // Seleccionar el canal del ADC según el pin especificado
    uint32_t channel = pin & ADC_CHANNEL_MASK;
    REG_WRITE(ADC_CHANNEL_REG, (REG_READ(ADC_CHANNEL_REG) & ~(ADC_CHANNEL_MASK << ADC_CHANNEL_SHIFT)) |
                               (channel << ADC_CHANNEL_SHIFT));

    // Iniciar la conversión
    REG_WRITE(ADC_CTRL_REG, REG_READ(ADC_CTRL_REG) | (1 << ADC_START_BIT));

    // Esperar a que la conversión termine
    while (REG_READ(ADC_CTRL_REG) & (1 << ADC_START_BIT));

    // Leer el valor del ADC
    valor_leido_adc = REG_READ(ADC_DATA_REG) & 0xFFF;

    return valor_leido_adc;
}
