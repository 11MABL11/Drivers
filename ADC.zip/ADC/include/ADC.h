/***************************************************************************
 * FileName:        ADC.h
 * Dependencies:    stdint.h
 * Processor:       ESP32-WROOM-32
 * Board:           Generic
 * Program version: Eclipse IDE V. 4.27.0
 * Company:         ITCH
 * Description:     Descripción general del ADC.
 * Authors:         Mario Alejandro Briones Lara.
 * Updated:         06/2023
 ***************************************************************************/
#ifndef ADC_H
#define ADC_H

#include <stdint.h>

// Definiciones PIN.
#define PIN0   0
#define PIN2   2
#define PIN4   4
#define PIN15   15

// Inicializa el módulo ADC.
void ADC_Init(uint8_t pin);
// Lee el estado del pin especificado y devuelve el valor.
uint16_t ADC_ReadValue(uint8_t pin);

#endif /* ADC_H */
