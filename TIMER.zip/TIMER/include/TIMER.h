/**************************************************************************
 * FileName:        TIMER.h
 * Dependencies:
 * Processor:       ESP32-WROOM-32
 * Board:           Generic
 * Program version: Eclipse IDE V. 4.27.0
 * Company:         ITCH
 * Description:     Descripción general del TIMER.
 * Authors:         Mario Alejandro Briones Lara.
 * Updated:         06/2023
 ***************************************************************************/

#ifndef TIMER_H
#define TIMER_H

//Inicializa el temporizador.
void TIMER_Init(void);
//Inicia el temporizador.
void TIMER_Start(void);
//Detiene el temporizador.
void TIMER_Stop(void);
///Reinicia el temporizador.
void TIMER_Reset(void);

#endif /* TIMER_H */
