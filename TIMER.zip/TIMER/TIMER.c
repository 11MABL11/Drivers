/**************************************************************************
 * FileName:        TIMER.c
 * Dependencies:    TIMER.h
 * Processor:       ESP32-WROOM-32
 * Board:           Generic
 * Program version: Eclipse IDE V. 4.27.0
 * Company:         ITCH
 * Description:     Descripción general del TIMER.
 * Authors:         Mario Alejandro Briones Lara.
 * Updated:         06/2023
 ***************************************************************************/

#include <stdio.h>
#include <stdint.h>
#include "TIMER.h"

#define TIMER_CTRL_REG     0x3FF4F000  // Registro de control del temporizador
#define TIMER_ENABLE_BIT   0
#define TIMER_START_BIT    2
#define TIMER_RESET_BIT    4

/**************************************************************************
 * Function: TIMER_Init
 * Preconditions: -
 * Overview: Inicializa el temporizador.
 * Input: -
 * Output: -
 ***************************************************************************/

void TIMER_Init(void) {
    // Inicialización del temporizador

    // Configurar los registros y las interrupciones necesarias

    // Por ejemplo, habilitar el temporizador
    uint32_t ctrlRegValue = *(volatile uint32_t *)(TIMER_CTRL_REG);
    ctrlRegValue |= (1 << TIMER_ENABLE_BIT);
    *(volatile uint32_t *)(TIMER_CTRL_REG) = ctrlRegValue;
}

/**************************************************************************
 * Function: TIMER_Start
 * Preconditions: Se debe llamar a TIMER_Init antes de utilizar esta función.
 * Overview: Inicia el temporizador.
 * Input: -
 * Output: -
 ***************************************************************************/

void TIMER_Start(void) {
    // Inicio del temporizador

    // Iniciar el contador del temporizador y habilitar la interrupción

    // Por ejemplo, iniciar el temporizador
    uint32_t ctrlRegValue = *(volatile uint32_t *)(TIMER_CTRL_REG);
    ctrlRegValue |= (1 << TIMER_START_BIT);
    *(volatile uint32_t *)(TIMER_CTRL_REG) = ctrlRegValue;
}

/**************************************************************************
 * Function: TIMER_Stop
 * Preconditions: Se debe llamar a TIMER_Init antes de utilizar esta función.
 * Overview: Detiene el temporizador.
 * Input: -
 * Output: -
 ***************************************************************************/

void TIMER_Stop(void) {
    // Detención del temporizador

    // Detener el contador del temporizador y deshabilitar la interrupción

    // Por ejemplo, detener el temporizador
    uint32_t ctrlRegValue = *(volatile uint32_t *)(TIMER_CTRL_REG);
    ctrlRegValue &= ~(1 << TIMER_START_BIT);
    *(volatile uint32_t *)(TIMER_CTRL_REG) = ctrlRegValue;
}

/**************************************************************************
 * Function: TIMER_Reset
 * Preconditions: Se debe llamar a TIMER_Init antes de utilizar esta función.
 * Overview: Reinicia el temporizador.
 * Input: -
 * Output: -
 ***************************************************************************/

void TIMER_Reset(void) {
    // Reinicio del temporizador

    // Reiniciar el contador del temporizador y borrar las banderas de interrupción

    // Por ejemplo, reiniciar el temporizador
    uint32_t ctrlRegValue = *(volatile uint32_t *)(TIMER_CTRL_REG);
    ctrlRegValue |= (1 << TIMER_RESET_BIT);
    *(volatile uint32_t *)(TIMER_CTRL_REG) = ctrlRegValue;
}
