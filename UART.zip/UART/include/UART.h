/**************************************************************************
 * FileName:        UART.h
 * Dependencies:    stdint
 * Processor:       ESP32-WROOM-32
 * Board:           Generic
 * Program version: Eclipse IDE V. 4.27.0
 * Company:         ITCH
 * Description:     Descripción general del UART.
 * Authors:         Mario Alejandro Briones Lara.
 * Updated:         06/2023
 ***************************************************************************/

#ifndef UART_H
#define UART_H

#include <stdint.h>

// Inicializa la interfaz UART.
void UART_Init(void);
// Transmite un byte a través de la interfaz UART.
void UART_TransmitByte(uint8_t data);
// Recibe un byte a través de la interfaz UART.
uint8_t UART_ReceiveByte(void);
// Transmite una cadena de caracteres a través de la interfaz UART.
void UART_SendString(const char* str);

#endif /* UART_H */
