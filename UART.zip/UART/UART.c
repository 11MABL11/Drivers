/***************************************************************************
 * FileName:        UART.c
 * Dependencies:    UART.h
 * Processor:       ESP32-WROOM-32
 * Board:           Generic
 * Program version: Eclipse IDE V. 4.27.0
 * Company:         ITCH
 * Description:     Descripción general del UART.
 * Authors:         Mario Alejandro Briones Lara.
 * Updated:         06/2023
 ***************************************************************************/

#include <stdio.h>
#include "UART.h"

// Definiciones de los registros de la UART
#define UART_CTRL_REG     0x3FF48000  // Registro de control de la UART
#define UART_TX_REG       0x3FF48004  // Registro de transmisión de la UART
#define UART_RX_REG        0x3FF48008  // Registro de recepción de la UART

// Macro para leer un registro
#define REG_READ(addr) (*((volatile uint32_t*)(addr)))

// Macro para escribir un registro
#define REG_WRITE(addr, value) (*((volatile uint32_t*)(addr)) = (value))

/***************************************************************************
 * Function: UART_Init
 * Preconditions: -
 * Overview: Inicializa la UART.
 * Input: -
 * Output: -
 ***************************************************************************/

void UART_Init(void) {
    // Inicialización de la UART

    // Configurar los registros y parámetros necesarios para la UART
    // Por ejemplo, configurar la velocidad de transmisión y recepción,
    // el tamaño de los datos, el bit de parada, etc.

    // Configurar la velocidad de transmisión a 9600 baudios
    uint32_t uart_clk_div = 80;  // Frecuencia de reloj de la UART en MHz
    uint32_t baud_rate = 9600;
    uint32_t divisor = uart_clk_div * 1000000 / baud_rate;
    REG_WRITE(UART_CTRL_REG, divisor);

    // Otros ajustes de configuración de la UART

    printf("UART initialized\n");
}

/***************************************************************************
 * Function: UART_TransmitByte
 * Preconditions: Se debe llamar a UART_Init antes de utilizar esta función.
 * Overview: Transmite un byte a través de la UART.
 * Input: data - El byte a transmitir.
 * Output: -
 ***************************************************************************/

void UART_TransmitByte(uint8_t data) {
    // Transmisión de un byte a través de la UART

    // Esperar hasta que el registro de transmisión esté vacío
    while (!(REG_READ(UART_CTRL_REG) & (1 << 31)));

    // Escribir el byte en el registro de transmisión
    REG_WRITE(UART_TX_REG, data);

    printf("Transmitted byte: %u\n", data);
}

/***************************************************************************
 * Function: UART_ReceiveByte
 * Preconditions: Se debe llamar a UART_Init antes de utilizar esta función.
 * Overview: Recibe un byte a través de la UART.
 * Input: -
 * Output: El byte recibido.
 ***************************************************************************/

uint8_t UART_ReceiveByte(void) {
    // Recepción de un byte a través de la UART

    // Esperar hasta que el registro de recepción esté lleno
    while (!(REG_READ(UART_CTRL_REG) & (1 << 30)));

    // Leer el byte desde el registro de recepción
    uint8_t received_value_uart = REG_READ(UART_RX_REG);

    printf("Received byte: %u\n", received_value_uart);

    // Retornar el valor recibido
    return received_value_uart;
}

/***************************************************************************
 * Function: UART_SendString
 * Preconditions: Se debe llamar a UART_Init antes de utilizar esta función.
 * Overview: Transmite una cadena de caracteres a través de la UART.
 * Input: str - Puntero a la cadena de caracteres a transmitir.
 * Output: -
 ***************************************************************************/

void UART_SendString(const char* str) {
    // Transmisión de una cadena de caracteres a través de la UART

    // Enviar cada caracter de la cadena
    while (*str != '\0') {
        UART_TransmitByte(*str);
        str++;
    }
}
