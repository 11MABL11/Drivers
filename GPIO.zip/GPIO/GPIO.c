/**************************************************************************
 * FileName:        GPIO.c
 * Dependencies:    GPIO.H
 * Processor:       ESP32-WROOM-32
 * Board:			 Generic
 * Program version: Eclipse IDE V. 4.27.0
 * Company:         ITCH
 * Description:     Descripcion general del GPIO.
 * Authors:         Mario Alejandro Briones Lara.
 * Updated:         06/2023
 ***************************************************************************/

/**************************************************************************
 * Function: GPIO Driver
 * Preconditions: None
 * Overview: Este controlador proporciona funciones para controlar los pines GPIO en el microcontrolador ESP32-WROOM-32.
 * Input: None
 * Output: None
 *
 ****************************************************************************/

#include "GPIO.h"

// Direcciones de registro para controlar los GPIO
#define GPIO_OUT_REG     ((volatile uint32_t*) 0x3FF44004)  // Registro de salida
#define GPIO_SET_REG     ((volatile uint32_t*) 0x3FF44008)  // Registro para establecer el pin
#define GPIO_CLEAR_REG   ((volatile uint32_t*) 0x3FF4400C)  // Registro para limpiar el pin
#define GPIO_LEVEL_REG   ((volatile uint32_t*) 0x3FF44010)  // Registro de nivel del pin

// Máscaras de bits para los pines GPIO
#define PIN14_MASK       (1U << 14)
#define PIN16_MASK       (1U << 16)
#define PIN17_MASK       (1U << 17)
#define PIN18_MASK       (1U << 18)
#define PIN19_MASK       (1U << 19)
#define PIN21_MASK       (1U << 21)
#define PIN22_MASK       (1U << 22)
#define PIN23_MASK       (1U << 23)

/**************************************************************************
 * Function: GPIO_Init
 * Preconditions: None
 * Overview: Inicializa los pines GPIO como salidas/entradas.
 * Input: Pin - El número de pin a establecer
 * 		  Mode - Set_Input/Set_Output
 * 		  pullup - PULLUP_EN/PULLUP_DIS
 * Output: None
 *
 ****************************************************************************/
void GPIO_Init(uint8_t pin, uint8_t mode, uint8_t pullup) {
    uint32_t pin_mask = 0;

    switch (pin) {
        case PIN14:
            pin_mask = PIN14_MASK;
            break;
        case PIN16:
            pin_mask = PIN16_MASK;
            break;
        case PIN17:
            pin_mask = PIN17_MASK;
            break;
        case PIN18:
            pin_mask = PIN18_MASK;
            break;
        case PIN19:
            pin_mask = PIN19_MASK;
            break;
        case PIN21:
            pin_mask = PIN21_MASK;
            break;
        case PIN22:
            pin_mask = PIN22_MASK;
            break;
        case PIN23:
            pin_mask = PIN23_MASK;
            break;
        default:
            // Manejar un número de pin inválido aquí si es necesario
            break;
    }

    // Configurar el modo del pin (entrada o salida)
    if (mode == SET_OUTPUT) {
        *GPIO_OUT_REG |= pin_mask;
    } else if (mode == SET_INPUT) {
        *GPIO_OUT_REG &= ~pin_mask;
    }

    // Configurar pull-up/pull-down
    if (pullup == PULLUP_EN) {
        *GPIO_SET_REG = pin_mask;
    } else if (pullup == PULLUP_DIS) {
        *GPIO_CLEAR_REG = pin_mask;
    }
}

/**************************************************************************
 * Function: GPIO_SetPin
 * Preconditions: Se debe llamar a GPIO_Init antes de llamar a esta función.
 * Overview: Establece el pin especificado en alto.
 * Input: pin - El número de pin a establecer (PIN14, PIN16, PIN17, etc.)
 * Output: None
 *
 ****************************************************************************/
void GPIO_SetPin(uint8_t pin) {
    // Establece el estado del pin en alto
    if (pin == PIN14) {
        *GPIO_SET_REG = PIN14_MASK;
    } else if (pin == PIN16) {
        *GPIO_SET_REG = PIN16_MASK;
    } else if (pin == PIN17) {
        *GPIO_SET_REG = PIN17_MASK;
    } else if (pin == PIN18) {
        *GPIO_SET_REG = PIN18_MASK;
    } else if (pin == PIN19) {
        *GPIO_SET_REG = PIN19_MASK;
    } else if (pin == PIN21) {
        *GPIO_SET_REG = PIN21_MASK;
    } else if (pin == PIN22) {
        *GPIO_SET_REG = PIN22_MASK;
    } else if (pin == PIN23) {
        *GPIO_SET_REG = PIN23_MASK;
    }
}

/**************************************************************************
 * Function: GPIO_ClearPin
 * Preconditions: Se debe llamar a GPIO_Init antes de llamar a esta función.
 * Overview: Establece el pin especificado en bajo.
 * Input: pin - El número de pin a limpiar (PIN14, PIN16, PIN17, etc.)
 * Output: None
 *
 ****************************************************************************/
void GPIO_ClearPin(uint8_t pin) {
    // Establece el estado del pin en bajo
    if (pin == PIN14) {
        *GPIO_CLEAR_REG = PIN14_MASK;
    } else if (pin == PIN16) {
        *GPIO_CLEAR_REG = PIN16_MASK;
    } else if (pin == PIN17) {
        *GPIO_CLEAR_REG = PIN17_MASK;
    } else if (pin == PIN18) {
        *GPIO_CLEAR_REG = PIN18_MASK;
    } else if (pin == PIN19) {
        *GPIO_CLEAR_REG = PIN19_MASK;
    } else if (pin == PIN21) {
        *GPIO_CLEAR_REG = PIN21_MASK;
    } else if (pin == PIN22) {
        *GPIO_CLEAR_REG = PIN22_MASK;
    } else if (pin == PIN23) {
        *GPIO_CLEAR_REG = PIN23_MASK;
    }
}

/**************************************************************************
 * Function: GPIO_TogglePin
 * Preconditions: Se debe llamar a GPIO_Init antes de llamar a esta función.
 * Overview: Invierte el estado del pin especificado (de alto a bajo o de bajo a alto).
 * Input: pin - El número de pin a invertir (PIN14, PIN16, PIN17, etc.)
 * Output: None
 *
 ****************************************************************************/
void GPIO_TogglePin(uint8_t pin) {
    // Invierte el estado del pin (de alto a bajo o de bajo a alto)
    if (pin == PIN14) {
        if ((*GPIO_LEVEL_REG & PIN14_MASK) != 0) {
            *GPIO_CLEAR_REG = PIN14_MASK;
        } else {
            *GPIO_SET_REG = PIN14_MASK;
        }
    } else if (pin == PIN16) {
        if ((*GPIO_LEVEL_REG & PIN16_MASK) != 0) {
            *GPIO_CLEAR_REG = PIN16_MASK;
        } else {
            *GPIO_SET_REG = PIN16_MASK;
        }
    } else if (pin == PIN17) {
        if ((*GPIO_LEVEL_REG & PIN17_MASK) != 0) {
            *GPIO_CLEAR_REG = PIN17_MASK;
        } else {
            *GPIO_SET_REG = PIN17_MASK;
        }
    } else if (pin == PIN18) {
        if ((*GPIO_LEVEL_REG & PIN18_MASK) != 0) {
            *GPIO_CLEAR_REG = PIN18_MASK;
        } else {
            *GPIO_SET_REG = PIN18_MASK;
        }
    } else if (pin == PIN19) {
        if ((*GPIO_LEVEL_REG & PIN19_MASK) != 0) {
            *GPIO_CLEAR_REG = PIN19_MASK;
        } else {
            *GPIO_SET_REG = PIN19_MASK;
        }
    } else if (pin == PIN21) {
        if ((*GPIO_LEVEL_REG & PIN21_MASK) != 0) {
            *GPIO_CLEAR_REG = PIN21_MASK;
        } else {
            *GPIO_SET_REG = PIN21_MASK;
        }
    } else if (pin == PIN22) {
        if ((*GPIO_LEVEL_REG & PIN22_MASK) != 0) {
            *GPIO_CLEAR_REG = PIN22_MASK;
        } else {
            *GPIO_SET_REG = PIN22_MASK;
        }
    } else if (pin == PIN23) {
        if ((*GPIO_LEVEL_REG & PIN23_MASK) != 0) {
            *GPIO_CLEAR_REG = PIN23_MASK;
        } else {
            *GPIO_SET_REG = PIN23_MASK;
        }
    }
}

/**************************************************************************
 * Function: GPIO_ReadPin
 * Preconditions: Se debe llamar a GPIO_Init antes de llamar a esta función.
 * Overview: Lee el estado del pin especificado y devuelve el valor (1 o 0).
 * Input: pin - El número de pin a leer (PIN14, PIN16, PIN17, etc.)
 * Output: El estado del pin (1 o 0)
 *
 ****************************************************************************/
uint8_t GPIO_ReadPin(uint8_t pin) {
    // Lee el estado del pin y devuelve el valor (1 o 0)
    uint8_t pinState = 0;

    if (pin == PIN14) {
        pinState = ((*GPIO_LEVEL_REG & PIN14_MASK) != 0) ? 1 : 0;
    } else if (pin == PIN16) {
        pinState = ((*GPIO_LEVEL_REG & PIN16_MASK) != 0) ? 1 : 0;
    } else if (pin == PIN17) {
        pinState = ((*GPIO_LEVEL_REG & PIN17_MASK) != 0) ? 1 : 0;
    } else if (pin == PIN18) {
        pinState = ((*GPIO_LEVEL_REG & PIN18_MASK) != 0) ? 1 : 0;
    } else if (pin == PIN19) {
        pinState = ((*GPIO_LEVEL_REG & PIN19_MASK) != 0) ? 1 : 0;
    } else if (pin == PIN21) {
        pinState = ((*GPIO_LEVEL_REG & PIN21_MASK) != 0) ? 1 : 0;
    } else if (pin == PIN22) {
        pinState = ((*GPIO_LEVEL_REG & PIN22_MASK) != 0) ? 1 : 0;
    } else if (pin == PIN23) {
        pinState = ((*GPIO_LEVEL_REG & PIN23_MASK) != 0) ? 1 : 0;
    }

    return pinState;
}
