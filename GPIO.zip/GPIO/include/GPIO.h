/**************************************************************************
 * FileName:        GPIO.h
 * Dependencies:    stdint
 * Processor:       ESP32-WROOM-32
 * Board:			 Generic
 * Program version: Eclipse IDE V. 4.27.0
 * Company:         ITCH
 * Description:     Descripcion general del GPIO.
 * Authors:         Mario Alejandro Briones Lara.
 * Updated:         06/2023
 ***************************************************************************/

#ifndef GPIO_H
#define GPIO_H

#include <stdint.h>

// Definiciones PIN.
#define PIN14   14
#define PIN16   16
#define PIN17   17
#define PIN18   18
#define PIN19   19
#define PIN21   21
#define PIN22   22
#define PIN23   23

// Definiciones I/O.
#define SET_OUTPUT  1
#define SET_INPUT   0
#define PULLUP_EN   1
#define PULLUP_DIS  0
#define HIGH        1
#define LOW         0
#define INT_EN      1
#define INT_DIS     0

// Inicializa el módulo GPIO y configura los pines como salidas.
void GPIO_Init(uint8_t pin, uint8_t mode, uint8_t pullup);
// Establece el estado del pin especificado en alto.
void GPIO_SetPin(uint8_t pin);
// Establece el estado del pin especificado en bajo.
void GPIO_ClearPin(uint8_t pin);
// Alterna el estado del pin especificado (de alto a bajo o de bajo a alto).
void GPIO_TogglePin(uint8_t pin);
// Lee el estado del pin especificado y devuelve el valor (1 o 0).
uint8_t GPIO_ReadPin(uint8_t pin);

#endif /* GPIO_H */
